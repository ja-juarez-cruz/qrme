(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_138baib._.js","static/chunks/0u_._next_dist_compiled_next-devtools_index_13e48da.js","static/chunks/0u_._next_dist_compiled_react-dom_08_g06.._.js","static/chunks/0u_._next_dist_compiled_react-server-dom-turbopack_0u-pg5l._.js","static/chunks/0u_._next_dist_compiled_03yn8g0._.js","static/chunks/0u_._next_dist_client_0tqgeip._.js","static/chunks/0u_._next_dist_06hslfc._.js","static/chunks/0u_._@swc_helpers_cjs_0t0man0._.js"],
    source: "entry"
});
