(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/Documents_git_QRME_qrme-frontend_app_globals_0i5cldp.css","static/chunks/0u_._next_dist_00s8o7q._.js"],
    source: "dynamic"
});
