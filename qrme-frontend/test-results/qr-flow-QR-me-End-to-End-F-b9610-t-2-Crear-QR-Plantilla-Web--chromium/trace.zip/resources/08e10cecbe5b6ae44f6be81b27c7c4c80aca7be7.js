(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Documents/git/QRME/qrme-frontend/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createQRCode",
    ()=>createQRCode,
    "deleteQRCode",
    ()=>deleteQRCode,
    "getMyProfile",
    ()=>getMyProfile,
    "getPhotoUploadUrl",
    ()=>getPhotoUploadUrl,
    "getPublicQR",
    ()=>getPublicQR,
    "getTemplates",
    ()=>getTemplates,
    "listQRCodes",
    ()=>listQRCodes,
    "trackScan",
    ()=>trackScan,
    "updateQRCode",
    ()=>updateQRCode,
    "upsertProfile",
    ()=>upsertProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Documents/git/QRME/qrme-frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * QR.me — API client.
 */ const API_BASE_URL = ("TURBOPACK compile-time value", "https://pxo1j6kgi7.execute-api.us-east-1.amazonaws.com/dev");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
// ─── Fetch Helper ───────────────────────────────────────────────────────────
async function apiFetch(path, options = {}) {
    const token = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem('qrme_token') : "TURBOPACK unreachable";
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers || {}
    };
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    const res = await fetch(`${API_BASE_URL}${path}`, {
        ...options,
        headers
    });
    const data = await res.json();
    if (!res.ok) {
        throw new Error(data.error || `API error: ${res.status}`);
    }
    return data;
}
async function getTemplates() {
    return apiFetch('/public/templates');
}
async function getPublicQR(slug, qrId) {
    return apiFetch(`/public/qr/${slug}/${qrId}`);
}
async function trackScan(qrId) {
    return apiFetch(`/track/scan/${qrId}`, {
        method: 'POST'
    });
}
async function getMyProfile() {
    return apiFetch('/me/profile');
}
async function upsertProfile(data) {
    return apiFetch('/me/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
    });
}
async function getPhotoUploadUrl(contentType) {
    return apiFetch('/me/profile/photo-url', {
        method: 'POST',
        body: JSON.stringify({
            contentType
        })
    });
}
async function listQRCodes() {
    return apiFetch('/me/qrcodes');
}
async function createQRCode(data) {
    return apiFetch('/me/qrcodes', {
        method: 'POST',
        body: JSON.stringify(data)
    });
}
async function updateQRCode(qrId, data) {
    return apiFetch(`/me/qrcodes/${qrId}`, {
        method: 'PUT',
        body: JSON.stringify(data)
    });
}
async function deleteQRCode(qrId) {
    return apiFetch(`/me/qrcodes/${qrId}`, {
        method: 'DELETE'
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QRListPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/git/QRME/qrme-frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/git/QRME/qrme-frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/git/QRME/qrme-frontend/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/git/QRME/qrme-frontend/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function QRListPage() {
    _s();
    const [qrcodes, setQrcodes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [deleting, setDeleting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [fetchError, setFetchError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "QRListPage.useEffect": ()=>{
            loadQRs();
        }
    }["QRListPage.useEffect"], []);
    const loadQRs = async ()=>{
        setFetchError(false);
        try {
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listQRCodes"])();
            setQrcodes(data.qrcodes || []);
        } catch (err) {
            console.error('Error loading QRs:', err);
            setFetchError(true);
        } finally{
            setLoading(false);
        }
    };
    const handleDelete = async (qrId)=>{
        if (!confirm('¿Seguro que quieres eliminar este QR?')) return;
        setDeleting(qrId);
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteQRCode"])(qrId);
            setQrcodes((prev)=>prev.filter((q)=>q.qrId !== qrId));
        } catch (err) {
            console.error('Error deleting:', err);
        } finally{
            setDeleting(null);
        }
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "glass-card p-8 text-center text-[var(--color-text-muted)]",
            children: "Cargando QRs..."
        }, void 0, false, {
            fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
            lineNumber: 55,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "animate-fade-in",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold",
                                children: "Mis Códigos QR"
                            }, void 0, false, {
                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                lineNumber: 65,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-[var(--color-text-muted)] mt-1",
                                children: [
                                    qrcodes.length,
                                    " QR",
                                    qrcodes.length !== 1 ? 's' : '',
                                    " creado",
                                    qrcodes.length !== 1 ? 's' : ''
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/dashboard/qrs/new",
                        className: "btn-primary",
                        children: "➕ Crear QR"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            fetchError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "glass-card p-12 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-5xl mb-4",
                        children: "⚠️"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 77,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-bold mb-2",
                        children: "Error al cargar QRs"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 78,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[var(--color-text-muted)] mb-6",
                        children: "No se pudo conectar con el servidor. Revisa tu sesión e intenta de nuevo."
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setLoading(true);
                            loadQRs();
                        },
                        className: "btn-primary",
                        children: "🔄 Reintentar"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                lineNumber: 76,
                columnNumber: 9
            }, this) : qrcodes.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "glass-card p-12 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-5xl mb-4",
                        children: "📱"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 88,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-bold mb-2",
                        children: "Aún no tienes QRs"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 89,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[var(--color-text-muted)] mb-6",
                        children: "Crea tu primer código QR y empieza a conectar con las personas"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 90,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/dashboard/qrs/new",
                        className: "btn-primary",
                        children: "🚀 Crear mi primer QR"
                    }, void 0, false, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 93,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                lineNumber: 87,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-4 stagger-children",
                children: qrcodes.map((qr)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "glass-card p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 glass-card-hover transition-all duration-300",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 mb-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-bold text-lg truncate",
                                                children: qr.label || 'Sin nombre'
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                                lineNumber: 106,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "badge text-xs",
                                                children: qr.templateId
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                                lineNumber: 109,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                        lineNumber: 105,
                                        columnNumber: 17
                                    }, this),
                                    qr.tagline && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[var(--color-text-muted)] text-sm mb-2 truncate",
                                        children: [
                                            "“",
                                            qr.tagline,
                                            "”"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                        lineNumber: 114,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-4 text-xs text-[var(--color-text-muted)]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex items-center gap-1",
                                                children: [
                                                    "📊 ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        className: "text-[var(--color-success)]",
                                                        children: qr.scanCount
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                                        lineNumber: 120,
                                                        columnNumber: 24
                                                    }, this),
                                                    " escaneos"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                                lineNumber: 119,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    "🕐 ",
                                                    new Date(qr.createdAt).toLocaleDateString('es-MX')
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                                lineNumber: 122,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                        lineNumber: 118,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                lineNumber: 104,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 shrink-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: qr.targetUrl,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "btn-secondary text-sm py-2 px-3",
                                        children: "👁️ Ver"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                        lineNumber: 129,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$git$2f$QRME$2f$qrme$2d$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>handleDelete(qr.qrId),
                                        disabled: deleting === qr.qrId,
                                        className: "btn-danger text-sm py-2 px-3 disabled:opacity-50",
                                        children: deleting === qr.qrId ? '⏳' : '🗑️'
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                        lineNumber: 137,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                                lineNumber: 128,
                                columnNumber: 15
                            }, this)
                        ]
                    }, qr.qrId, true, {
                        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                        lineNumber: 100,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
                lineNumber: 98,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/git/QRME/qrme-frontend/app/dashboard/qrs/page.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, this);
}
_s(QRListPage, "0QmntFzD5SCC9HKataKcKy0b5e0=");
_c = QRListPage;
var _c;
__turbopack_context__.k.register(_c, "QRListPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Documents_git_QRME_qrme-frontend_0jruu7s._.js.map